Course files for 'Statistics and Probability for Computer Science'. 

Course TBA. 

http://recluze.net
